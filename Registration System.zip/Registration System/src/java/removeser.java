import javax.servlet.*;
import java.io.*;
import java.sql.*;

public class removeser extends GenericServlet
{
    public void service(ServletRequest req,ServletResponse res)
            throws ServletException, IOException
    {
       try
       {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();

         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	 Connection con=DriverManager.getConnection("jdbc:odbc:regidsn");

        int i;

        String dnm=req.getParameter("txtdnm");
        String del=req.getParameter("delete");

	Statement st=con.createStatement();

        if(del.equals("delete"))
        {
           i=st.executeUpdate("delete from User where Name='"+dnm+"'");
           out.print("<h2>deleted sucessfully</h2>");
        }
	st.close();
	con.close();
       }
       catch(SQLException e){}
       catch(ClassNotFoundException e){}
    }
}