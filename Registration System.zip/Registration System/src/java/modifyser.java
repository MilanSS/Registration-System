import javax.servlet.*;
import java.io.*;
import java.sql.*;

public class modifyser extends GenericServlet
{
    public void service(ServletRequest req,ServletResponse res)
            throws ServletException, IOException
    {
       try
       {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();

         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	 Connection con=DriverManager.getConnection("jdbc:odbc:regidsn");

        int i;

        String mnm=req.getParameter("txtmnm");
        String mad=req.getParameter("txtmad");
        String mphn=req.getParameter("txtmphn");
        String mbu=req.getParameter("update");

	Statement st=con.createStatement();

        if(mbu.equals("update"))
        {
           i=st.executeUpdate("update User set Address='"+mad+"',Phone No='"+mphn+"' where Name='"+mnm+"'");
           out.print("<h1>Updated sucessfully<h1>");
        }
	st.close();
	con.close();
       }
       catch(SQLException e){}
       catch(ClassNotFoundException e){}
    }
}