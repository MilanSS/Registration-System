import javax.servlet.*;
import java.io.*;
import java.sql.*;

public class showser extends GenericServlet
{
    public void service(ServletRequest req,ServletResponse res)
            throws ServletException, IOException
    {
       try
       {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();

         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	 Connection con=DriverManager.getConnection("jdbc:odbc:regidsn");

       	Statement st=con.createStatement();

        ResultSet rs=st.executeQuery("select * from User ");
                out.print("<br><br><br>");
                out.print("<center>");
                out.print("<h1>User Table...</h1>");
                out.print("<table border=2>");
                out.print("<tr>");
                out.print("<th>Name</th>");
                out.print("<th>Address</th>");
                out.print("<th>E-mail id</th>");
                out.print("<th>Qualification</th>");
                out.print("<th>Phone No</th>");
                out.print("<th>Gender</th>");
                out.print("</tr>");
	while(rs.next())
        {
 		out.print("<tr>");
                out.print("<td>"+rs.getString(1)+"</td>");
                out.print("<td>"+rs.getString(2)+"</td>");
                out.print("<td>"+rs.getString(3)+"</td>");
                out.print("<td>"+rs.getString(4)+"</td>");
                out.print("<td>"+rs.getString(5)+"</td>");
                out.print("<td>"+rs.getString(6)+"</td>");
                
                out.print("</tr>");
               
        }
                 out.print("</table>");
                  out.print("</center>");
	

	st.close();
	con.close();
       }
       catch(SQLException e){}
       catch(ClassNotFoundException e){}
    }
}