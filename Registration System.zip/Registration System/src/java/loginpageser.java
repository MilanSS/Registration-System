import javax.servlet.*;
import java.io.*;

public class loginpageser extends GenericServlet
{
    public void service(ServletRequest req,ServletResponse res)
            throws ServletException, IOException
    {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();


        String unm =req.getParameter("txtnm");
        String psw=req.getParameter("txtpas");
      

        if(unm.equals("admin"))
        {
            if(psw.equals("123"))
            {
                 RequestDispatcher rd=req.getRequestDispatcher("afterlogin.jsp");
                 rd.include(req,res);
            }
        }
        else
        {
              RequestDispatcher rd=req.getRequestDispatcher("welcome.jsp");
              rd.include(req,res);
        }
        
    }
}