import javax.servlet.*;
import java.io.*;
import java.sql.*;

public class registerser extends GenericServlet
{
    public void service(ServletRequest req,ServletResponse res)
            throws ServletException, IOException
    {
       try
       {
        res.setContentType("text/html");
        PrintWriter out=res.getWriter();

         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	 Connection con=DriverManager.getConnection("jdbc:odbc:regidsn");

        int i;
        
        String rnm=req.getParameter("txtrnm");
        String rad=req.getParameter("txtrad");
        String reid=req.getParameter("txtreid");
        String rqul=req.getParameter("txtrqul");
        String rph=req.getParameter("txtrph");
        String rgen=req.getParameter("gender");
        String rbu=req.getParameter("add");

	Statement st=con.createStatement();

        if(rbu.equals("Add"))
        {
           i=st.executeUpdate("insert into User values('"+rnm+"','"+rad+"','"+reid+"','"+rqul+"','"+rph+"','"+rgen+"')");
           out.print("<h1>inserted sucessfully<h1>");
        }
	st.close();
	con.close();
       }
       catch(SQLException e){}
       catch(ClassNotFoundException e){}
    }
}